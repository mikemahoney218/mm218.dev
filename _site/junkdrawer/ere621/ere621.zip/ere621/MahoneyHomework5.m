%ERE621 - Spatial Analysis
%Homework #5
%Mike Mahoney

clear all; close all; clc
load ('SA_HW5_Data.mat')

%% Part 1: Exploration
% Calculating and Visualizing Cross K Function Estimation 
InMat = Deer11;

boundary = get_bbox(InMat(:, 1:2));
area = polyarea(boundary(:, 1), boundary(:, 2));

% Calculate L-values:
l_vals = mahoney_cross_k_function(InMat, 200, area);

% Plot values:
figure('Name', 'Cross-L Deer11')
plot(l_vals(:, 1), l_vals(:, 2))

%% Part 2: Modeling
% Simulations for the Lij(h) function 

%% Deer 11
InMat = Deer11;

boundary = get_bbox(InMat(:, 1:2));
area = polyarea(boundary(:, 1), boundary(:, 2));

l_vals = mahoney_cross_l_test(InMat, 200, area, 100);
l_vals(:, 5) = (l_vals(:, 3) + l_vals(:, 4)) / 2;

figure('Name', 'Envelope Cross-L Deer11')
plot(l_vals(:, 1), l_vals(:, 2) - l_vals(:, 5))
hold on
plot(l_vals(:, 1), l_vals(:, 3) - l_vals(:, 5), '--', 'Color', 'red')
plot(l_vals(:, 1), l_vals(:, 4) - l_vals(:, 5), '--', 'Color', 'green')
hold off
ylim([-600, 200])

% This data set exhibits spatial dependence of subpopulations at distances
% between 0 and 19,000 units. Male deer exhibit much more regularity than
% expected at these distances when using random labels. Beyond distances of
% approximately 19,000 units, populations appear to exhibit spatial
% independence. At distances of approximately 29,000 units and beyond this
% data exhibits spatial dependence between subpopulations again, with male
% deer exhibiting slightly more clustering than the random case.

%% Deer 10

InMat = Deer10;

boundary = get_bbox(InMat(:, 1:2));
area = polyarea(boundary(:, 1), boundary(:, 2));

l_vals = mahoney_cross_l_test(InMat, 200, area, 100);
l_vals(:, 5) = (l_vals(:, 3) + l_vals(:, 4)) / 2;

figure('Name', 'Envelope Cross-L Deer10')
plot(l_vals(:, 1), l_vals(:, 2) - l_vals(:, 5))
hold on
plot(l_vals(:, 1), l_vals(:, 3) - l_vals(:, 5), '--', 'Color', 'red')
plot(l_vals(:, 1), l_vals(:, 4) - l_vals(:, 5), '--', 'Color', 'green')
hold off

% This data set exhibits spatial dependence of subpopulations between
% distances of 0 and 2,500 units, where male deer appear to have much more 
% regularity compared to the female population than the random case,
% between approximately 3,300 and 4,200 units, where male deer appear to
% exhibit more clustering compared to the female population than the random
% case, and at distances beyond 31,200 units where male deer again exhibit
% more clustering than expected given the random case.
% At all other distances these subpopulations appear to be spatially
% independent.

%% Deer 9

InMat = Deer9;

boundary = get_bbox(InMat(:, 1:2));
area = polyarea(boundary(:, 1), boundary(:, 2));

l_vals = mahoney_cross_l_test(InMat, 200, area, 100);
l_vals(:, 5) = (l_vals(:, 3) + l_vals(:, 4)) / 2;

figure('Name', 'Envelope Cross-L Deer9')
plot(l_vals(:, 1), l_vals(:, 2) - l_vals(:, 5))
hold on
plot(l_vals(:, 1), l_vals(:, 3) - l_vals(:, 5), '--', 'Color', 'red')
plot(l_vals(:, 1), l_vals(:, 4) - l_vals(:, 5), '--', 'Color', 'green')
hold off

% This data set appears to exhibit spatial independence between
% subpopulations at all distances. There are small ranges where the 
% subpopulations may exhibit spatial dependence -- between 18,000
% and 18,800 units distance male deer exhibit regularity compared to the
% random case, while beyond 29,200 units male deer exhibit clustering --
% but it is possible that additional simulations would expand the envelopes
% of the random case to incorporate these ranges.

%% Cancer

InMat = Cancer;

boundary = get_bbox(InMat(:, 1:2));
area = polyarea(boundary(:, 1), boundary(:, 2));

l_vals = mahoney_cross_l_test(InMat, 200, area, 100);
l_vals(:, 5) = (l_vals(:, 3) + l_vals(:, 4)) / 2;

figure('Name', 'Envelope Cross-L Cancer')
plot(l_vals(:, 1), l_vals(:, 2) - l_vals(:, 5))
hold on
plot(l_vals(:, 1), l_vals(:, 3) - l_vals(:, 5), '--', 'Color', 'red')
plot(l_vals(:, 1), l_vals(:, 4) - l_vals(:, 5), '--', 'Color', 'green')
hold off

% The subpopulations exhibit spatial independence at all distances. It does
% not appear that either larynx or lung cancer are more clustered or
% regular than the other at any distance.

%% 3. Comparing the Cross Lij(h) function with the regular L functions  

InMat = Deer11;

boundary = get_bbox(InMat(:, 1:2));
area = polyarea(boundary(:, 1), boundary(:, 2));

male_deer = Deer11(Deer11(:, 3) == 0, :);
female_deer = Deer11(Deer11(:, 3) == 1, :);

l_vals = mahoney_cross_l_test(InMat, 200, area, 100);
l_vals(:, 5) = (l_vals(:, 3) + l_vals(:, 4)) / 2;

figure('Name', 'Envelope Cross-L Deer11')
plot(l_vals(:, 1), l_vals(:, 2) - l_vals(:, 5))
hold on
plot(l_vals(:, 1), l_vals(:, 3) - l_vals(:, 5), '--', 'Color', 'red')
plot(l_vals(:, 1), l_vals(:, 4) - l_vals(:, 5), '--', 'Color', 'green')
hold off
ylim([-600, 200])

l_vals = mahoney_point_L_test(male_deer, 200, boundary, 100);
l_vals(:, 5) = (l_vals(:, 3) + l_vals(:, 4)) / 2;

figure('Name', 'L-Function: Male Deer11')
plot(l_vals(:, 1), l_vals(:, 2) - l_vals(:, 5))
hold on
plot(l_vals(:, 1), l_vals(:, 3) - l_vals(:, 5), '--', 'Color', 'red')
plot(l_vals(:, 1), l_vals(:, 4) - l_vals(:, 5), '--', 'Color', 'green')
hold off

l_vals = mahoney_point_L_test(female_deer, 200, boundary, 100);

l_vals(:, 5) = (l_vals(:, 3) + l_vals(:, 4)) / 2;

figure('Name', 'L-Function: Female Deer11')
plot(l_vals(:, 1), l_vals(:, 2) - l_vals(:, 5))
hold on
plot(l_vals(:, 1), l_vals(:, 3) - l_vals(:, 5), '--', 'Color', 'red')
plot(l_vals(:, 1), l_vals(:, 4) - l_vals(:, 5), '--', 'Color', 'green')
hold off

% Considered as separate populations, both the female and male deer exhibit
% clustering at almost all distances (though female deer possibly become 
% randomly distributed at distances beyond 26,300 units).
% For much of this range, male deer have a lower 
% L-value than female deer when compared at the same distances.
% This explains the regularity seen when looking at the L(male, female)
% graph: compared to the female subpopulation, male deer exhibit more
% regularity than would be expected if the two populations were spatially
% independent. At greater distances (approximately 19,000 units and above)
% the difference between the separate L-values becomes lesser, and the
% populations become spatially independent in the eyes of the cross-L
% function.

%% Functions

function output_values = mahoney_cross_k_function(XYL, n_bins, area)
    distances = cross_class_distance_matrix(XYL);
    bin_step = max(distances, [], 'all') / n_bins;
    
    first_class = XYL(XYL(:, 3) == min(XYL(:, 3)), :);
    second_class = XYL(XYL(:, 3) == max(XYL(:, 3)), :);
    fc_s = size(first_class);
    fc_s = fc_s(1);
    sc_s = size(second_class);
    sc_s = sc_s(1);
    
    constant = area / (fc_s * sc_s);
    
    output_values = zeros(n_bins, 2);
    
    current_distance = 0;
    for i = 1:n_bins
        current_distance = current_distance + bin_step;
        in_range = distances <= current_distance;
        output_values(i, 1) = current_distance;
        output_values(i, 2) = (sum(in_range, 'all'));
    end
    
    % convert counts to K-values
    output_values(:, 2) = output_values(:, 2) * constant;
    % convert K-values to L-values
    output_values(:, 2) = sqrt(output_values(:, 2) / pi) - output_values(:, 1);

end

function output_values = mahoney_cross_l_test(XYL, n_bins, area, n_sims)
    distances = cross_class_distance_matrix(XYL);
    bin_step = max(distances, [], 'all') / n_bins;
    
    first_class = XYL(XYL(:, 3) == min(XYL(:, 3)), :);
    second_class = XYL(XYL(:, 3) == max(XYL(:, 3)), :);
    fc_s = size(first_class);
    fc_s = fc_s(1);
    sc_s = size(second_class);
    sc_s = sc_s(1);
    
    constant = area / (fc_s * sc_s);
    
    output_values = zeros(n_bins, 4);
    output_values(:, 3) = 99999;
    
    current_distance = 0;
    for i = 1:n_bins
        current_distance = current_distance + bin_step;
        in_range = distances <= current_distance;
        output_values(i, 1) = current_distance;
        output_values(i, 2) = (sum(in_range, 'all'));
    end
    
    for i = 1:n_sims
        XYL(:, 3) = random_labeling_help(fc_s, sc_s);
        for j = 1:n_bins
            current_distance = output_values(j, 1);
            
            distances = cross_class_distance_matrix(XYL);
            distances(distances == 0) = NaN;
            
            in_range = distances <= current_distance;
            in_range = (sum(in_range, 'all'));
            
            output_values(j, 3) = min(output_values(j, 3), in_range);
            output_values(j, 4) = max(output_values(j, 4), in_range);
        end
    end
    
    % convert counts to K-values
    output_values(:, 2) = output_values(:, 2) * constant;
    output_values(:, 3) = output_values(:, 3) * constant;
    output_values(:, 4) = output_values(:, 4) * constant;
    % convert K-values to L-values
    output_values(:, 2) = sqrt(output_values(:, 2) / pi) - output_values(:, 1);
    output_values(:, 3) = sqrt(output_values(:, 3) / pi) - output_values(:, 1);
    output_values(:, 4) = sqrt(output_values(:, 4) / pi) - output_values(:, 1);    

end

function point_boundary = get_bbox(XY)
    [min_bounds, max_bounds] = bounds(XY);
    point_boundary = zeros(4, 2);
    point_boundary(1, 1) = min_bounds(1);
    point_boundary(1, 2) = min_bounds(2);
    point_boundary(2, 1) = min_bounds(1);
    point_boundary(2, 2) = max_bounds(2);
    point_boundary(3, 1) = max_bounds(1);
    point_boundary(3, 2) = max_bounds(2);
    point_boundary(4, 1) = max_bounds(1);
    point_boundary(4, 2) = min_bounds(2);
end

function m = cross_class_distance_matrix(XYL)
    first_class = XYL(XYL(:, 3) == min(XYL(:, 3)), :);
    second_class = XYL(XYL(:, 3) == max(XYL(:, 3)), :);
    fc_s = size(first_class);
    fc_s = fc_s(1);
    
    sc_s = size(second_class);
    sc_s = sc_s(1);
    m = zeros(fc_s, sc_s);
    for i = 1:fc_s
        for j = 1:sc_s
            m(i, j) = sqrt((first_class(i, 1) - second_class(j, 1))^2 + (first_class(i, 2) - second_class(j, 2))^2);
        end
    end
end

function m = make_distance_matrix(XY)
    s = size(XY);
    s = s(1);
    m = zeros(s);
    for i = 1:s
        for j = 1:s
            m(j, i) = sqrt((XY(i, 1) - XY(j, 1))^2 + (XY(i, 2) - XY(j, 2))^2);
        m(i, j) = m(j, i);
        end
    end
end

function output_values = mahoney_point_L_test(XY, n_bins, boundary, n_sims)
    distances = make_distance_matrix(XY);
    bin_step = max(distances, [], 'all') / n_bins;
    distances(distances == 0) = NaN;
    
    n_events = size(XY);
    n_events = n_events(1);
    
    area = polyarea(boundary(:, 1), boundary(:, 2));
    
    output_values = zeros(n_bins, 4);
    output_values(:, 3) = 99999;
    
    current_distance = 0;
    for i = 1:n_bins
        current_distance = current_distance + bin_step;
        in_range = distances <= current_distance;
        output_values(i, 1) = current_distance;
        output_values(i, 2) = (sum(in_range, 'all'));
    end

    for i = 1:n_sims
        current_sim = create_random_points_within_boundary(XY, boundary);
        for j = 1:n_bins
            current_distance = output_values(j, 1);
            
            distances = make_distance_matrix(current_sim);
            distances(distances == 0) = NaN;
            
            in_range = distances <= current_distance;
            in_range = (sum(in_range, 'all'));
            
            output_values(j, 3) = min(output_values(j, 3), in_range);
            output_values(j, 4) = max(output_values(j, 4), in_range);
        end
    end
    
    % convert counts to K-values
    output_values(:, 2) = output_values(:, 2) * (area / (n_events^2));
    output_values(:, 3) = output_values(:, 3) * (area / (n_events^2));
    output_values(:, 4) = output_values(:, 4) * (area / (n_events^2));
    % convert K-values to L-values
    output_values(:, 2) = sqrt(output_values(:, 2) / pi) - output_values(:, 1);
    output_values(:, 3) = sqrt(output_values(:, 3) / pi) - output_values(:, 1);
    output_values(:, 4) = sqrt(output_values(:, 4) / pi) - output_values(:, 1);

end

function [type_vector] = random_labeling_help (type_0_count,type_1_count)
%Function caluclates a random vector of two event types, used for random
%labeling

%Calculations
vector_length = type_0_count + type_1_count;
p = randperm(vector_length);
type_vector(p(1:type_0_count))=0;
type_vector(p(type_0_count+1:vector_length))=1;

%Output
type_vector;
end

function [coordinate_random_inside] = create_random_points_within_boundary(coordinate, boundary)
% Creates random points within a boundary

%Written By Giorgos Mountrakis, 09/26/2006

%INPUTS
% (i) coordinate: X,Y POINT coordinates in a nx2 format % Used only
% to extract point size n and minimum bounding box
% (ii) boundary: X,Y BOUNDARY coordinates in a kx2 format 

%DEPENDENCIES
% Calls 'pt_in_poly' function to identify points inside polygon

%OUTPUTS
% (i)  coordinate_random_inside: X,Y POINT coordinates in a nx2 format
% randomly generated that are within the boundary


[n1,n2]=size(coordinate);
PointX=coordinate(:,1);
PointY=coordinate(:,2);
minX=min(PointX); maxX=max(PointX); minY=min(PointY) ;maxY=max(PointY);
total_points = n1;

n1 = 5*n1; % 5x the points and from those select total_points that fall within the polygon area

% Create a random XY dataset within the minimum bounding rectangle
PointX_rand = rand(n1, 1);
l=maxX - minX; k =minX;
PointX_rand_scaled = (l .*PointX_rand) + k;
PointY_rand = rand(n1, 1);
l=maxY - minY; k =minY;
PointY_rand_scaled = (l .*PointY_rand) + k;
coordinate_random = [PointX_rand_scaled        PointY_rand_scaled];

% Examine the random XY dataset to see which points fall within the
% boundary and extract the first "total_points" points

complete_dataset =0;
coordinate_random_inside = zeros(total_points,2);
ic = 0;
iw = 0;
while complete_dataset ==0
    ic = ic +1;
    out = pt_in_poly(coordinate_random(ic,:),boundary);
    if out ==1
        iw = iw +1;
        coordinate_random_inside(iw,:) = coordinate_random(ic,:);
        if iw==total_points; complete_dataset =1;end
    end

end %while

coordinate_random_inside;
end

function out = pt_in_poly(x,poly);
n = size(poly,1);

u = ones(n,1);

YY = poly - u*x;

Z = YY(:,1) + i*YY(:,2);

theta = angle(Z);

M = [theta(2:end),theta(1:end-1)];

I1 = (M(:,1).*M(:,2) < 0); %find opposite sign cases

I2 = (abs(M(:,1)) + abs(M(:,2)) > pi); %find tot abs > pi

I = I1.*I2; %Combine to get "bad" cases

Diff = M(:,1) - M(:,2);

u1 = ones(n-1,1);

R = (u1 - I).*Diff + I.*(Diff -2*pi*sign(Diff));

tot = sum(R);

if abs(tot) > 1
    
    out = 1;
    
else
    
    out = 0;
    
end

end