%ERE621 - Spatial Analysis
%Final Project
%Mike Mahoney
clear all; close all; clc

bbox = [
    0, 0;
    0, 140;
    140, 140; 
    140, 0
    ];
area = polyarea(bbox(:, 1), bbox(:, 2));

beech_85 = readmatrix("1985_beech.csv");
beech_00 = readmatrix("2000_beech.csv");
beech_09 = readmatrix("2009_beech.csv");
beech_85 = mahoney_cross_l_test(beech_85, 200, area, 100);
beech_00 = mahoney_cross_l_test(beech_00, 200, area, 100);
beech_09 = mahoney_cross_l_test(beech_09, 200, area, 100);

red_maple_85 = readmatrix("1985_red_maple.csv");
red_maple_00 = readmatrix("2000_red_maple.csv");
red_maple_09 = readmatrix("2009_red_maple.csv");
red_maple_85 = mahoney_cross_l_test(red_maple_85, 200, area, 100);
red_maple_00 = mahoney_cross_l_test(red_maple_00, 200, area, 100);
red_maple_09 = mahoney_cross_l_test(red_maple_09, 200, area, 100);

sugar_maple_85 = readmatrix("1985_sugar_maple.csv");
sugar_maple_00 = readmatrix("2000_sugar_maple.csv");
sugar_maple_09 = readmatrix("2009_sugar_maple.csv");
sugar_maple_85 = mahoney_cross_l_test(sugar_maple_85, 200, area, 100);
sugar_maple_00 = mahoney_cross_l_test(sugar_maple_00, 200, area, 100);
sugar_maple_09 = mahoney_cross_l_test(sugar_maple_09, 200, area, 100);

yellow_birch_85 = readmatrix("1985_yellow_birch.csv");
yellow_birch_00 = readmatrix("2000_yellow_birch.csv");
yellow_birch_09 = readmatrix("2009_yellow_birch.csv");
yellow_birch_85 = mahoney_cross_l_test(yellow_birch_85, 200, area, 100);
yellow_birch_00 = mahoney_cross_l_test(yellow_birch_00, 200, area, 100);
yellow_birch_09 = mahoney_cross_l_test(yellow_birch_09, 200, area, 100);

%% Figures

figure('name', 'Cross-L Functions')
subplot(4, 3, 1)
plot(beech_85(:, 1), beech_85(:, 2) - beech_85(:, 5))
hold on
plot(beech_85(:, 1), beech_85(:, 3) - beech_85(:, 5), '--', 'Color', 'red')
plot(beech_85(:, 1), beech_85(:, 4) - beech_85(:, 5), '--', 'Color', 'green')
hold off
title('Beech: 1985')

subplot(4, 3, 2)
plot(beech_00(:, 1), beech_00(:, 2) - beech_00(:, 5))
hold on
plot(beech_00(:, 1), beech_00(:, 3) - beech_00(:, 5), '--', 'Color', 'red')
plot(beech_00(:, 1), beech_00(:, 4) - beech_00(:, 5), '--', 'Color', 'green')
hold off
title('Beech: 2000')

subplot(4, 3, 3)
plot(beech_09(:, 1), beech_09(:, 2) - beech_09(:, 5))
hold on
plot(beech_09(:, 1), beech_09(:, 3) - beech_09(:, 5), '--', 'Color', 'red')
plot(beech_09(:, 1), beech_09(:, 4) - beech_09(:, 5), '--', 'Color', 'green')
hold off
title('Beech: 2009')

subplot(4, 3, 4)
plot(red_maple_85(:, 1), red_maple_85(:, 2) - red_maple_85(:, 5))
hold on
plot(red_maple_85(:, 1), red_maple_85(:, 3) - red_maple_85(:, 5), '--', 'Color', 'red')
plot(red_maple_85(:, 1), red_maple_85(:, 4) - red_maple_85(:, 5), '--', 'Color', 'green')
hold off
title('Red maple: 1985')

subplot(4, 3, 5)
plot(red_maple_00(:, 1), red_maple_00(:, 2) - red_maple_00(:, 5))
hold on
plot(red_maple_00(:, 1), red_maple_00(:, 3) - red_maple_00(:, 5), '--', 'Color', 'red')
plot(red_maple_00(:, 1), red_maple_00(:, 4) - red_maple_00(:, 5), '--', 'Color', 'green')
hold off
title('Red maple: 2000')

subplot(4, 3, 6)
plot(red_maple_09(:, 1), red_maple_09(:, 2) - red_maple_09(:, 5))
hold on
plot(red_maple_09(:, 1), red_maple_09(:, 3) - red_maple_09(:, 5), '--', 'Color', 'red')
plot(red_maple_09(:, 1), red_maple_09(:, 4) - red_maple_09(:, 5), '--', 'Color', 'green')
hold off
title('Red maple: 2009')

subplot(4, 3, 7)
plot(sugar_maple_85(:, 1), sugar_maple_85(:, 2) - sugar_maple_85(:, 5))
hold on
plot(sugar_maple_85(:, 1), sugar_maple_85(:, 3) - sugar_maple_85(:, 5), '--', 'Color', 'red')
plot(sugar_maple_85(:, 1), sugar_maple_85(:, 4) - sugar_maple_85(:, 5), '--', 'Color', 'green')
hold off
title('Sugar maple: 1985')

subplot(4, 3, 8)
plot(sugar_maple_00(:, 1), sugar_maple_00(:, 2) - sugar_maple_00(:, 5))
hold on
plot(sugar_maple_00(:, 1), sugar_maple_00(:, 3) - sugar_maple_00(:, 5), '--', 'Color', 'red')
plot(sugar_maple_00(:, 1), sugar_maple_00(:, 4) - sugar_maple_00(:, 5), '--', 'Color', 'green')
hold off
title('Sugar maple: 2000')

subplot(4, 3, 9)
plot(sugar_maple_09(:, 1), sugar_maple_09(:, 2) - sugar_maple_09(:, 5))
hold on
plot(sugar_maple_09(:, 1), sugar_maple_09(:, 3) - sugar_maple_09(:, 5), '--', 'Color', 'red')
plot(sugar_maple_09(:, 1), sugar_maple_09(:, 4) - sugar_maple_09(:, 5), '--', 'Color', 'green')
hold off
title('Sugar maple: 2009')

subplot(4, 3, 10)
plot(yellow_birch_85(:, 1), yellow_birch_85(:, 2) - yellow_birch_85(:, 5))
hold on
plot(yellow_birch_85(:, 1), yellow_birch_85(:, 3) - yellow_birch_85(:, 5), '--', 'Color', 'red')
plot(yellow_birch_85(:, 1), yellow_birch_85(:, 4) - yellow_birch_85(:, 5), '--', 'Color', 'green')
hold off
title('Yellow birch: 1985')

subplot(4, 3, 11)
plot(yellow_birch_00(:, 1), yellow_birch_00(:, 2) - yellow_birch_00(:, 5))
hold on
plot(yellow_birch_00(:, 1), yellow_birch_00(:, 3) - yellow_birch_00(:, 5), '--', 'Color', 'red')
plot(yellow_birch_00(:, 1), yellow_birch_00(:, 4) - yellow_birch_00(:, 5), '--', 'Color', 'green')
hold off
title('Yellow birch: 2000')

subplot(4, 3, 12)
plot(yellow_birch_09(:, 1), yellow_birch_09(:, 2) - yellow_birch_09(:, 5))
hold on
plot(yellow_birch_09(:, 1), yellow_birch_09(:, 3) - yellow_birch_09(:, 5), '--', 'Color', 'red')
plot(yellow_birch_09(:, 1), yellow_birch_09(:, 4) - yellow_birch_09(:, 5), '--', 'Color', 'green')
hold off
title('Yellow birch: 2009')

figure('name', 'Cross-L Functions')
subplot(4, 3, 1)
plot(beech_85(:, 1), beech_85(:, 2) - beech_85(:, 5))
hold on
plot(beech_85(:, 1), beech_85(:, 3) - beech_85(:, 5), '--', 'Color', 'red')
plot(beech_85(:, 1), beech_85(:, 4) - beech_85(:, 5), '--', 'Color', 'green')
hold off
title('Beech: 1985')
xlim([0, 60])

subplot(4, 3, 2)
plot(beech_00(:, 1), beech_00(:, 2) - beech_00(:, 5))
hold on
plot(beech_00(:, 1), beech_00(:, 3) - beech_00(:, 5), '--', 'Color', 'red')
plot(beech_00(:, 1), beech_00(:, 4) - beech_00(:, 5), '--', 'Color', 'green')
hold off
title('Beech: 2000')
xlim([0, 60])

subplot(4, 3, 3)
plot(beech_09(:, 1), beech_09(:, 2) - beech_09(:, 5))
hold on
plot(beech_09(:, 1), beech_09(:, 3) - beech_09(:, 5), '--', 'Color', 'red')
plot(beech_09(:, 1), beech_09(:, 4) - beech_09(:, 5), '--', 'Color', 'green')
hold off
title('Beech: 2009')
xlim([0, 60])

subplot(4, 3, 4)
plot(red_maple_85(:, 1), red_maple_85(:, 2) - red_maple_85(:, 5))
hold on
plot(red_maple_85(:, 1), red_maple_85(:, 3) - red_maple_85(:, 5), '--', 'Color', 'red')
plot(red_maple_85(:, 1), red_maple_85(:, 4) - red_maple_85(:, 5), '--', 'Color', 'green')
hold off
title('Red maple: 1985')
xlim([0, 60])

subplot(4, 3, 5)
plot(red_maple_00(:, 1), red_maple_00(:, 2) - red_maple_00(:, 5))
hold on
plot(red_maple_00(:, 1), red_maple_00(:, 3) - red_maple_00(:, 5), '--', 'Color', 'red')
plot(red_maple_00(:, 1), red_maple_00(:, 4) - red_maple_00(:, 5), '--', 'Color', 'green')
hold off
title('Red maple: 2000')
xlim([0, 60])

subplot(4, 3, 6)
plot(red_maple_09(:, 1), red_maple_09(:, 2) - red_maple_09(:, 5))
hold on
plot(red_maple_09(:, 1), red_maple_09(:, 3) - red_maple_09(:, 5), '--', 'Color', 'red')
plot(red_maple_09(:, 1), red_maple_09(:, 4) - red_maple_09(:, 5), '--', 'Color', 'green')
hold off
title('Red maple: 2009')
xlim([0, 60])

subplot(4, 3, 7)
plot(sugar_maple_85(:, 1), sugar_maple_85(:, 2) - sugar_maple_85(:, 5))
hold on
plot(sugar_maple_85(:, 1), sugar_maple_85(:, 3) - sugar_maple_85(:, 5), '--', 'Color', 'red')
plot(sugar_maple_85(:, 1), sugar_maple_85(:, 4) - sugar_maple_85(:, 5), '--', 'Color', 'green')
hold off
title('Sugar maple: 1985')
xlim([0, 60])

subplot(4, 3, 8)
plot(sugar_maple_00(:, 1), sugar_maple_00(:, 2) - sugar_maple_00(:, 5))
hold on
plot(sugar_maple_00(:, 1), sugar_maple_00(:, 3) - sugar_maple_00(:, 5), '--', 'Color', 'red')
plot(sugar_maple_00(:, 1), sugar_maple_00(:, 4) - sugar_maple_00(:, 5), '--', 'Color', 'green')
hold off
title('Sugar maple: 2000')
xlim([0, 60])

subplot(4, 3, 9)
plot(sugar_maple_09(:, 1), sugar_maple_09(:, 2) - sugar_maple_09(:, 5))
hold on
plot(sugar_maple_09(:, 1), sugar_maple_09(:, 3) - sugar_maple_09(:, 5), '--', 'Color', 'red')
plot(sugar_maple_09(:, 1), sugar_maple_09(:, 4) - sugar_maple_09(:, 5), '--', 'Color', 'green')
hold off
title('Sugar maple: 2009')
xlim([0, 60])

subplot(4, 3, 10)
plot(yellow_birch_85(:, 1), yellow_birch_85(:, 2) - yellow_birch_85(:, 5))
hold on
plot(yellow_birch_85(:, 1), yellow_birch_85(:, 3) - yellow_birch_85(:, 5), '--', 'Color', 'red')
plot(yellow_birch_85(:, 1), yellow_birch_85(:, 4) - yellow_birch_85(:, 5), '--', 'Color', 'green')
hold off
title('Yellow birch: 1985')
xlim([0, 60])

subplot(4, 3, 11)
plot(yellow_birch_00(:, 1), yellow_birch_00(:, 2) - yellow_birch_00(:, 5))
hold on
plot(yellow_birch_00(:, 1), yellow_birch_00(:, 3) - yellow_birch_00(:, 5), '--', 'Color', 'red')
plot(yellow_birch_00(:, 1), yellow_birch_00(:, 4) - yellow_birch_00(:, 5), '--', 'Color', 'green')
hold off
title('Yellow birch: 2000')
xlim([0, 60])

subplot(4, 3, 12)
plot(yellow_birch_09(:, 1), yellow_birch_09(:, 2) - yellow_birch_09(:, 5))
hold on
plot(yellow_birch_09(:, 1), yellow_birch_09(:, 3) - yellow_birch_09(:, 5), '--', 'Color', 'red')
plot(yellow_birch_09(:, 1), yellow_birch_09(:, 4) - yellow_birch_09(:, 5), '--', 'Color', 'green')
hold off
title('Yellow birch: 2009')
xlim([0, 60])

%% Functions
function output_values = mahoney_cross_l_test(XYL, n_bins, area, n_sims)
    distances = cross_class_distance_matrix(XYL);
    bin_step = max(distances, [], 'all') / n_bins;
    
    first_class = XYL(XYL(:, 3) == min(XYL(:, 3)), :);
    second_class = XYL(XYL(:, 3) == max(XYL(:, 3)), :);
    fc_s = size(first_class);
    fc_s = fc_s(1);
    sc_s = size(second_class);
    sc_s = sc_s(1);
    
    constant = area / (fc_s * sc_s);


    output_values = zeros(n_bins, 4);
    output_values(:, 3) = 99999;
    
    current_distance = 0;
    for i = 1:n_bins
        current_distance = current_distance + bin_step;
        in_range = distances <= current_distance;
        output_values(i, 1) = current_distance;
        output_values(i, 2) = (sum(in_range, 'all'));
    end
    
    for i = 1:n_sims
        XYL(:, 3) = random_labeling_help(fc_s, sc_s);
        for j = 1:n_bins
            current_distance = output_values(j, 1);
            
            distances = cross_class_distance_matrix(XYL);
            distances(distances == 0) = NaN;
            
            in_range = distances <= current_distance;
            in_range = (sum(in_range, 'all'));
            
            output_values(j, 3) = min(output_values(j, 3), in_range);
            output_values(j, 4) = max(output_values(j, 4), in_range);
        end
    end
    
    % convert counts to K-values
    output_values(:, 2) = output_values(:, 2) * constant;
    output_values(:, 3) = output_values(:, 3) * constant;
    output_values(:, 4) = output_values(:, 4) * constant;
    % convert K-values to L-values
    output_values(:, 2) = sqrt(output_values(:, 2) / pi) - output_values(:, 1);
    output_values(:, 3) = sqrt(output_values(:, 3) / pi) - output_values(:, 1);
    output_values(:, 4) = sqrt(output_values(:, 4) / pi) - output_values(:, 1); 
    output_values(:, 5) = (output_values(:, 3) + output_values(:, 4)) / 2;

end


function m = cross_class_distance_matrix(XYL)
    first_class = XYL(XYL(:, 3) == min(XYL(:, 3)), :);
    second_class = XYL(XYL(:, 3) == max(XYL(:, 3)), :);
    fc_s = size(first_class);
    fc_s = fc_s(1);
    
    sc_s = size(second_class);
    sc_s = sc_s(1);
    m = zeros(fc_s, sc_s);
    for i = 1:fc_s
        for j = 1:sc_s
            m(i, j) = sqrt((first_class(i, 1) - second_class(j, 1))^2 + (first_class(i, 2) - second_class(j, 2))^2);
        end
    end
end

function [type_vector] = random_labeling_help (type_0_count,type_1_count)
%Function caluclates a random vector of two event types, used for random
%labeling

%Calculations
vector_length = type_0_count + type_1_count;
p = randperm(vector_length);
type_vector(p(1:type_0_count))=0;
type_vector(p(type_0_count+1:vector_length))=1;

end

function [coordinate_random_inside] = create_random_points_within_boundary(coordinate, boundary)
% Creates random points within a boundary

%Written By Giorgos Mountrakis, 09/26/2006

%INPUTS
% (i) coordinate: X,Y POINT coordinates in a nx2 format % Used only
% to extract point size n and minimum bounding box
% (ii) boundary: X,Y BOUNDARY coordinates in a kx2 format 

%DEPENDENCIES
% Calls 'pt_in_poly' function to identify points inside polygon

%OUTPUTS
% (i)  coordinate_random_inside: X,Y POINT coordinates in a nx2 format
% randomly generated that are within the boundary


[n1,n2]=size(coordinate);
PointX=coordinate(:,1);
PointY=coordinate(:,2);
minX=min(PointX); maxX=max(PointX); minY=min(PointY) ;maxY=max(PointY);
total_points = n1;

n1 = 5*n1; % 5x the points and from those select total_points that fall within the polygon area

% Create a random XY dataset within the minimum bounding rectangle
PointX_rand = rand(n1, 1);
l=maxX - minX; k =minX;
PointX_rand_scaled = (l .*PointX_rand) + k;
PointY_rand = rand(n1, 1);
l=maxY - minY; k =minY;
PointY_rand_scaled = (l .*PointY_rand) + k;
coordinate_random = [PointX_rand_scaled        PointY_rand_scaled];

% Examine the random XY dataset to see which points fall within the
% boundary and extract the first "total_points" points

complete_dataset =0;
coordinate_random_inside = zeros(total_points,2);
ic = 0;
iw = 0;
while complete_dataset ==0
    ic = ic +1;
    out = pt_in_poly(coordinate_random(ic,:),boundary);
    if out ==1
        iw = iw +1;
        coordinate_random_inside(iw,:) = coordinate_random(ic,:);
        if iw==total_points; complete_dataset =1;end
    end

end %while
end

function out = pt_in_poly(x,poly);
n = size(poly,1);

u = ones(n,1);

YY = poly - u*x;

Z = YY(:,1) + i*YY(:,2);

theta = angle(Z);

M = [theta(2:end),theta(1:end-1)];

I1 = (M(:,1).*M(:,2) < 0); %find opposite sign cases

I2 = (abs(M(:,1)) + abs(M(:,2)) > pi); %find tot abs > pi

I = I1.*I2; %Combine to get "bad" cases

Diff = M(:,1) - M(:,2);

u1 = ones(n-1,1);

R = (u1 - I).*Diff + I.*(Diff -2*pi*sign(Diff));

tot = sum(R);

if abs(tot) > 1
    
    out = 1;
    
else
    
    out = 0;
    
end

end